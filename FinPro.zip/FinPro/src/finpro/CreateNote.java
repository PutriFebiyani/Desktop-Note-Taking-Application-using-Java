/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finpro;
import java.util.Scanner;
/**
 *
 * @author Asus
 */
public class CreateNote extends Note {
    CreateNote(String folderName) {
        super(folderName);
    }
    
    void inputFolderName() {
        Koneksi con = new Koneksi();
        String columnName = "folderID";
        String query = "SELECT * FROM msfolder ORDER BY folderID DESC LIMIT 1";
        int id=con.createConnection(columnName, query);
        String folderID="FD";
        id++;
            
        folderID = folderID.concat(String.format("%03d", id));
        query = "INSERT INTO msfolder (folderID, folderName) VALUES('"+folderID+"', '"+super.getFolderName()+"')";
        con.createConnection(query);
    }
    
    void inputTitle(String folderID, String noteName, String content) {
        Koneksi con = new Koneksi();
        String columnName = "noteID";
        super.setNoteTitle(noteName);
        super.setContent(content);
        String query = "SELECT noteID FROM msnote WHERE folderID='"+folderID+"' ORDER BY noteID DESC LIMIT 1";
        int id=con.createConnection(columnName, query);
        id++;
        String noteID = "NT";
        noteID = noteID.concat(String.format("%03d", id));
        
        query = "INSERT INTO msnote (folderID, noteID, noteName, noteContent) VALUES('"+folderID+"', '"+noteID+"', '"+noteName+"', '"+content+"')";
        con.createConnection(query);
    }
}
