/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finpro;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
/**
 *
 * @author Asus
 */
class searchNote {
    private Timer timer;
    private ArrayList<Note> noteSource;
    private ArrayList<Note> notes;

    void SearchNote(ArrayList<Note> noteSource) {
        this.noteSource = noteSource;
        this.notes = new ArrayList<>(noteSource);
    }

    void searchNotes(String searchKeyword) {
        if (timer != null) {
            timer.cancel();
        }

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (searchKeyword.trim().isEmpty()) {
                    notes = new ArrayList<>(noteSource);
                } else {
                    ArrayList<Note> temp = new ArrayList<>();
                    for (Note note : noteSource) {
                        if (note.getNoteTitle().toLowerCase().contains(searchKeyword.toLowerCase())
                                || note.getContent().toLowerCase().contains(searchKeyword.toLowerCase())) {
                            temp.add(note);
                        }
                    }
                    notes = temp;
                }
            }
        }, 500);
        if (searchKeyword.trim().isEmpty()) {
            notes = new ArrayList<>(noteSource);
        }
    }

    public void cancelSearch() {
        if (timer != null) {
            timer.cancel();
        }
    }
}

