/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finpro;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Asus
 */
public class Koneksi {
    private static Connection con;
    String DB="jdbc:mysql://localhost:3306/NoteAPP"; // delta_db database
    String user="root"; // user database
    String pass=""; // password database
    ArrayList<String> noteName = new ArrayList<>();
    ArrayList<String> content = new ArrayList<>();
    void createConnection(String query) {
        try{  
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(DB, user, pass);
            Statement stmt = con.createStatement();
            stmt.executeUpdate(query);
            con.close();
        }catch(ClassNotFoundException ex){
            Logger.getLogger(FinPro.class.getName()).log(Level.SEVERE, null, ex);
        }catch(SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    int createConnection(String columnName, String query) {
        int id=0;
        try{ 
            String str_id = null;
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            con = (Connection) DriverManager.getConnection(DB, user, pass);
            Statement stmt = con.createStatement();
            stmt.executeQuery(query);
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()) {
                str_id = rs.getString(columnName);            
            }

            if(str_id !=null) {
                id = Integer.parseInt(str_id.substring(2));
            }
            con.close();

        }catch(ClassNotFoundException ex){
            Logger.getLogger(FinPro.class.getName()).log(Level.SEVERE, null, ex);
        }catch(SQLException ex) {
            ex.printStackTrace();
        }
        return id;
    }
    
    void updateNoteContent(String folderID, String noteID, String newContent) {
        String query = "UPDATE msnote SET noteContent = '" + newContent + "' WHERE folderID = '" + folderID
                + "' AND noteID = '" + noteID + "'";
        createConnection(query);
    }

    void updateNoteTitle(String folderID, String noteID, String newTitle) {
        String query = "UPDATE msnote SET noteName = '" + newTitle + "' WHERE folderID = '" + folderID
                + "' AND noteID = '" + noteID + "'";
        createConnection(query);
    }

    void updateFolderName(String folderID, String newFolderName) {
        String query = "UPDATE msfolder SET folderName = '" + newFolderName + "' WHERE folderID = '" + folderID + "'";
        createConnection(query);
    }
    
    ArrayList<String> createConnection2(String query) {
        ArrayList<String> folderName = new ArrayList<>();
        try{ 
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            con = (Connection) DriverManager.getConnection(DB, user, pass);
            Statement stmt = con.createStatement();
            stmt.executeQuery(query);
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()) {
                folderName.add(rs.getString("folderName"));            
            }
            con.close();

        }catch(ClassNotFoundException ex){
            Logger.getLogger(FinPro.class.getName()).log(Level.SEVERE, null, ex);
        }catch(SQLException ex) {
            ex.printStackTrace();
        }
        return folderName;
    }  
        ArrayList<String> createConnection3(String query) {
            ArrayList<String> noteName=new ArrayList<>();
            try{ 
                Class.forName("com.mysql.cj.jdbc.Driver");

                con = (Connection) DriverManager.getConnection(DB, user, pass);
                Statement stmt = con.createStatement();
                stmt.executeQuery(query);
                ResultSet rs = stmt.executeQuery(query);
                while(rs.next()) {
                    noteName.add(rs.getString("noteName"));       
                }
                con.close();

                }catch(ClassNotFoundException ex){
                    Logger.getLogger(FinPro.class.getName()).log(Level.SEVERE, null, ex);
                }catch(SQLException ex) {
                    ex.printStackTrace();
                }
            return noteName;
        }
        
        
        String createConnection4(String query, String columnName) {
        String str_id=null;
        try{ 
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            con = (Connection) DriverManager.getConnection(DB, user, pass);
            Statement stmt = con.createStatement();
            stmt.executeQuery(query);
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()) {
                str_id = rs.getString(columnName);            
            }

            con.close();

        }catch(ClassNotFoundException ex){
            Logger.getLogger(FinPro.class.getName()).log(Level.SEVERE, null, ex);
        }catch(SQLException ex) {
            ex.printStackTrace();
        }
        return str_id;
    }
        
        ArrayList<String> createConnection5(String query, String columnName) {
            ArrayList<String> noteName=new ArrayList<>();
            try{ 
                Class.forName("com.mysql.cj.jdbc.Driver");

                con = (Connection) DriverManager.getConnection(DB, user, pass);
                Statement stmt = con.createStatement();
                stmt.executeQuery(query);
                ResultSet rs = stmt.executeQuery(query);
                while(rs.next()) {
                    noteName.add(rs.getString("noteName"));       
                    content.add(rs.getString(columnName));
                }
                con.close();

                }catch(ClassNotFoundException ex){
                    Logger.getLogger(FinPro.class.getName()).log(Level.SEVERE, null, ex);
                }catch(SQLException ex) {
                    ex.printStackTrace();
                }
            return noteName;
        }
}
