/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finpro;

/**
 *
 * @author Asus
 */
public class updateNote {
    Koneksi con = new Koneksi();
    void updateNoteContent(String folderID, String noteID, String newContent) {
        String query = "UPDATE msnote SET noteContent = '" + newContent + "' WHERE folderID = '" + folderID
                + "' AND noteID = '" + noteID + "'";
        con.createConnection(query);
    }

    void updateNoteTitle(String folderID, String noteID, String newTitle) {
        String query = "UPDATE msnote SET noteName = '" + newTitle + "' WHERE folderID = '" + folderID
                + "' AND noteID = '" + noteID + "'";
        con.createConnection(query);
    }

    void updateFolderName(String folderID, String newFolderName) {
        String query = "UPDATE msfolder SET folderName = '" + newFolderName + "' WHERE folderID = '" + folderID + "'";
        con.createConnection(query);
    }
}
