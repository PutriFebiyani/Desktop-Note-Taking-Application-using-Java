/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finpro;


/**
 *
 * @author Asus
 */
public class DeleteNote {
    Koneksi con = new Koneksi();
    void deleteFolder(String folderID) {
            String deleteNotesQuery = "DELETE FROM msnote WHERE folderID='" + folderID + "'";
            String deleteFolderQuery = "DELETE FROM msfolder WHERE folderID='" + folderID + "'";
            
            con.createConnection(deleteNotesQuery);
            con.createConnection(deleteFolderQuery);
    }

    void deleteNote(String folderID, String noteName) {
            String deleteNoteQuery = "DELETE FROM msnote WHERE folderID='" + folderID + "' AND noteName='" + noteName + "'";            
            con.createConnection(deleteNoteQuery);    
    }
}
