/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finpro;
import java.util.Scanner;
/**
 *
 * @author Asus
 */
public class FinPro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int menu;
        Scanner sc = new Scanner(System.in);
        menu = sc.nextInt();
        sc.nextLine();
        String folderName=null;
        CreateNote note = new CreateNote(folderName);
        ReadNote rnote = new ReadNote();
        switch(menu) {
            case 1: //create folder
                folderName = sc.nextLine();
                note.setFolderName(folderName);
                note.inputFolderName();
                break;
            case 2: //create note
//                note.inputTitle();
                break;
            case 3: //read list folder (sorted by yg duluan dibuat di atas)
                rnote.readFolder_ByMadeAsc();
                break;
            case 4: //read list folder (sorted by yg terakhir dibuat di atas)
                rnote.readFolder_ByMadeDesc();
                break; 
            case 5: //read list folder (sorted by nama folder asc)
                rnote.readFolderAsc();
                break;
            case 6: //read list folder (sorted by nama folder desc)
                rnote.readFolderDesc();
                break;
//            case 7: //read list notenya+kasi liat content dikit (sorted by yg duluan dibuat di atas)
//                rnote.readNoteAsc();
//                break;
//            case 8: //read list notenya+kasi liat content dikit (sorted by yg terakhir dibuat di atas)
//                rnote.readNoteDesc();
//                break;
//            case 9: //read list notenya+kasi liat content dikit (sorted by nama note asc)
//                rnote.readNote_ByNameAsc();
//                break;
//            case 10: //read list notenya+kasi liat content dikit (sorted by nama note desc)
//                rnote.readNote_ByNameDesc();
//                break;
            case 11: //tampilin judul note+isinya
//                rnote.readNote();
                break;
        }
        sc.close();
    }
    
}
