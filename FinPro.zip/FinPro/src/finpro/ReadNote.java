/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finpro;
import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author Asus
 */
class ReadNote {
    String query;
    Koneksi con = new Koneksi();
    Scanner sc = new Scanner(System.in);
    String folderID, noteID, columnName;
    ArrayList<String> readFolder_ByMadeAsc() {
        query = "SELECT folderName FROM msfolder ORDER BY folderID ASC";
        ArrayList<String> folderName = con.createConnection2(query);
        return folderName;
    }
    ArrayList<String> readFolder_ByMadeDesc() {
        query = "SELECT folderName FROM msfolder ORDER BY folderID DESC";
        ArrayList<String> folderName = con.createConnection2(query);
        return folderName;
    }
    ArrayList<String> readFolderAsc() {
        query = "SELECT folderName FROM msfolder ORDER BY folderName ASC";
        ArrayList<String> folderName = con.createConnection2(query);
        return folderName;
    }
    ArrayList<String> readFolderDesc() {
        query = "SELECT folderName FROM msfolder ORDER BY folderName DESC";
        ArrayList<String> folderName = con.createConnection2(query);
        return folderName;
    }
    ArrayList<String> readNoteAsc(String folderID) {
        query = "SELECT noteName FROM MsNote WHERE folderID='"+folderID+"' ORDER BY noteID ASC";
        ArrayList<String> noteName = con.createConnection3(query);
        return noteName;
    }
    ArrayList<String> readNoteDesc(String folderID) {
        query = "SELECT noteName FROM MsNote WHERE folderID='"+folderID+"' ORDER BY noteID DESC";
        ArrayList<String> noteName = con.createConnection3(query);
        return noteName;
    }
    ArrayList<String> readNote_ByNameAsc(String folderID) {
        query = "SELECT noteName FROM MsNote WHERE folderID='"+folderID+"' ORDER BY noteID ASC";
        ArrayList<String> noteName = con.createConnection3(query);
        return noteName;
    }
    ArrayList<String> readNote_ByNameDesc(String folderID) {
        query = "SELECT noteName FROM MsNote WHERE folderID='"+folderID+"' ORDER BY noteID DESC";
        ArrayList<String> noteName = con.createConnection3(query);
        return noteName;
    }
    void readNote(String folderID, String noteID) {
        columnName = "noteContent";
        query = "SELECT noteName, noteContent FROM msnote WHERE folderID='"+folderID+"' AND noteID='"+noteID+"'";
        con.createConnection5(query, columnName);
    }
}
