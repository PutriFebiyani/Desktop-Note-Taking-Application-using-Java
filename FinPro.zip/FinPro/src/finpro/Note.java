/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finpro;

/**
 *
 * @author Asus
 */
public class Note {
    private String folderName;
    private String noteTitle;
    private String content;
    Note(String folderName) {
        this.folderName = folderName;
    }
    Note(String noteTitle, String content) {
        this.noteTitle = noteTitle;
        this.content = content;
    }
    String getFolderName() {
        return this.folderName;
    }
    String getNoteTitle() {
        return this.noteTitle;
    }
    String getContent() {
        return this.content;
    }
    
    void setFolderName(String folderName) {
        this.folderName = folderName;
    }
    
    void setNoteTitle(String noteTitle) {
        this.noteTitle = noteTitle;
    }
    
    void setContent(String content) {
        this.content = content;
    }
}
